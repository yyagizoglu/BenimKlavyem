package com.example.mykeyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// hdr: 0 düz başlık, 1 Sabitlenenler, 2 Geçmiş, 3 sabit çöp kutusu, 4 geçmiş çöp kutusu
data class ClipItem(
    val text: String, val pinned: Boolean, val header: Boolean = false, val title: String = "",
    val color: Int = 0, val num: Int = 0, val time: Long = 0L, val trash: Boolean = false,
    val hdr: Int = 0, val countA: Int = 0
)

class ClipAdapter(
    private val onInsert: (ClipItem) -> Unit,
    private val onPin: (ClipItem) -> Unit,
    private val onDelete: (ClipItem) -> Unit,
    private val onEdit: (ClipItem) -> Unit,
    private val onDrag: (RecyclerView.ViewHolder) -> Unit,
    private val onHeader: (ClipItem, Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        // Not kâğıdı renkleri (açık tonlar; yazı her zaman koyu)
        val PALETTE = intArrayOf(
            0xFFFFF59D.toInt(), 0xFFF8BBD0.toInt(), 0xFFB3E5FC.toInt(), 0xFFC8E6C9.toInt(),
            0xFFFFCCBC.toInt(), 0xFFD1C4E9.toInt(), 0xFFB2DFDB.toInt(), 0xFFFFE0B2.toInt()
        )
        private val fmt = SimpleDateFormat("dd.MM HH:mm", Locale("tr"))   // yıl yok: gün.ay saat
        fun stamp(t: Long) = if (t <= 0L) "" else fmt.format(Date(t))
    }

    var items: MutableList<ClipItem> = mutableListOf()

    fun submit(list: MutableList<ClipItem>) { items = list; notifyDataSetChanged() }

    fun move(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= items.size || to >= items.size) return
        items.add(to, items.removeAt(from))
        notifyItemMoved(from, to)
    }

    // Sürükleme bitince sıra numaralarını yenile
    fun renumber() {
        var c = 0; var hc = 0
        for (k in items.indices) {
            val it = items[k]
            if (it.header || it.trash) continue
            if (it.pinned) { c++; items[k] = it.copy(num = c) } else { hc++; items[k] = it.copy(num = hc) }
        }
        if (items.isNotEmpty()) notifyItemRangeChanged(0, items.size)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.clipText)
        val title: TextView? = v.findViewById(R.id.clipTitle)
        val time: TextView? = v.findViewById(R.id.clipTime)
        val body: View = v.findViewById<View>(R.id.clipBody) ?: text
        val num: TextView? = v.findViewById(R.id.clipNum)
        val pin: TextView = v.findViewById(R.id.clipPin)
        val del: TextView = v.findViewById(R.id.clipDel)
        val drag: TextView = v.findViewById(R.id.clipDrag)
    }

    class HVH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.clipHeader)
        val a: TextView = v.findViewById(R.id.hdrA)
        val b: TextView = v.findViewById(R.id.hdrB)
    }

    override fun getItemViewType(position: Int) = if (items[position].header) 2 else if (items[position].pinned && !items[position].trash) 1 else 0

    override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(p.context)
        return if (t == 2) HVH(inf.inflate(R.layout.item_header, p, false))
        else VH(inf.inflate(if (t == 1) R.layout.item_pinned else R.layout.item_clip, p, false))
    }

    override fun getItemCount() = items.size

    private fun cur(h: VH): ClipItem? = items.getOrNull(h.bindingAdapterPosition)

    private fun bindHeader(h: HVH, item: ClipItem) {
        h.title.text = item.text
        fun btn(v: TextView, label: String?, which: Int) {
            if (label == null) { v.visibility = View.GONE; return }
            v.text = label; v.visibility = View.VISIBLE
            v.setOnClickListener { items.getOrNull(h.bindingAdapterPosition)?.let { onHeader(it, which) } }
        }
        when (item.hdr) {
            1 -> { btn(h.a, if (item.countA > 0) "♻ Çöp (${item.countA})" else null, 0); btn(h.b, null, 1) }
            2 -> { btn(h.a, if (item.countA > 0) "♻ Çöp (${item.countA})" else null, 0); btn(h.b, "🗑", 1) }
            3, 4 -> { btn(h.a, "← Geri", 0); btn(h.b, if (item.countA > 0) "Boşalt" else null, 1) }
            else -> { btn(h.a, null, 0); btn(h.b, null, 1) }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {
        val item = items[i]
        if (holder is HVH) { bindHeader(holder, item); return }
        val h = holder as VH
        val full = item.pinned && !item.trash   // not kâğıdı kartı
        h.text.text = if (item.trash && item.title.isNotEmpty()) "${item.title} — ${item.text}" else item.text
        h.title?.let { t ->
            if (full && item.title.isNotEmpty()) { t.text = item.title; t.visibility = View.VISIBLE }
            else t.visibility = View.GONE
        }
        h.time?.let { t ->
            val s = stamp(item.time)
            if (!full && s.isNotEmpty()) { t.text = s; t.visibility = View.VISIBLE } else t.visibility = View.GONE
        }
        h.num?.let { n ->
            if (item.num > 0) { n.text = "${item.num}."; n.visibility = View.VISIBLE } else n.visibility = View.GONE
        }
        h.pin.text = if (item.trash) "↩" else if (item.pinned) "★" else "☆"
        h.drag.visibility = if (item.trash) View.GONE else View.VISIBLE
        if (full) {
            h.itemView.background = GradientDrawable().apply {
                setColor(PALETTE[item.color.mod(PALETTE.size)]); cornerRadius = 6f * h.itemView.resources.displayMetrics.density
                setStroke(1, Color.argb(60, 0, 0, 0))
            }
        } else h.itemView.setBackgroundResource(R.drawable.key_bg)
        h.body.setOnClickListener { cur(h)?.let(onInsert) }
        // Basılı tut: Düzenle / Sil menüsü
        h.body.setOnLongClickListener { cur(h)?.let { if (!it.trash) onEdit(it) }; true }
        h.pin.setOnClickListener { cur(h)?.let(onPin) }
        h.del.setOnClickListener { cur(h)?.let(onDelete) }
        h.drag.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) onDrag(h)
            false
        }
    }
}
