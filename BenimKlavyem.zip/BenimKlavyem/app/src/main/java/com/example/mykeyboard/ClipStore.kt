package com.example.mykeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ClipStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("clips", Context.MODE_PRIVATE)

    // Bozuk/eksik kayıt klavyeyi çökertmesin
    private fun load(key: String): MutableList<String> = try {
        val a = JSONArray(sp.getString(key, "[]"))
        MutableList(a.length()) { a.getString(it) }
    } catch (_: Exception) { mutableListOf() }
    private fun save(key: String, l: List<String>) {
        sp.edit().putString(key, JSONArray(l).toString()).apply()
    }

    // Sabitlenenlere isteğe bağlı başlık: metin -> başlık (eski kayıtlarla uyumlu, ayrı anahtarda tutulur)
    private fun loadTitles(): MutableMap<String, String> = try {
        val o = JSONObject(sp.getString("titles", "{}"))
        val m = LinkedHashMap<String, String>()
        val ks = o.keys()
        while (ks.hasNext()) { val k = ks.next(); m[k] = o.getString(k) }
        m
    } catch (_: Exception) { mutableMapOf() }
    private fun saveTitles(m: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        sp.edit().putString("titles", o.toString()).apply()
    }
    fun titles(): Map<String, String> = loadTitles()
    fun setTitle(t: String, title: String) {
        val m = loadTitles()
        val clean = title.replace('\n', ' ').trim()
        if (clean.isEmpty()) m.remove(t) else m[t] = clean
        saveTitles(m)
    }
    private fun dropTitle(t: String) {
        val m = loadTitles()
        if (m.remove(t) != null) saveTitles(m)
    }

    fun history() = load("history")
    fun pinned() = load("pinned")
    fun saveHistory(l: List<String>) = save("history", l)
    fun savePinned(l: List<String>) = save("pinned", l)

    fun addHistory(t: String) {
        val h = history()
        h.remove(t)
        h.add(0, t)
        while (h.size > 50) h.removeAt(h.size - 1)
        saveHistory(h)
    }
    fun pin(t: String) {
        val h = history(); h.remove(t); saveHistory(h)
        val p = pinned(); p.remove(t); p.add(t); savePinned(p)   // yeni sabit sona eklenir: numara kaldığı yerden devam eder
    }
    // Silinen sabiti eski yerine geri koy
    fun restorePinned(t: String, idx: Int) {
        val h = history(); if (h.remove(t)) saveHistory(h)
        val p = pinned(); p.remove(t); p.add(idx.coerceIn(0, p.size), t); savePinned(p)
    }
    fun unpin(t: String) {
        val p = pinned(); p.remove(t); savePinned(p)
        addHistory(t)
    }
    fun delete(t: String, fromPinned: Boolean) {
        if (fromPinned) { val p = pinned(); p.remove(t); savePinned(p) }
        else { val h = history(); h.remove(t); saveHistory(h) }
        dropTitle(t)
    }
    fun replace(old: String, new: String, fromPinned: Boolean) {
        val l = if (fromPinned) pinned() else history()
        val i = l.indexOf(old)
        if (i < 0) return
        l[i] = new
        val d = l.distinct()
        if (fromPinned) {
            savePinned(d)
            // Metin değişince başlık da yeni metne taşınsın
            if (old != new) {
                val m = loadTitles()
                val t = m.remove(old)
                if (t != null) { if (!m.containsKey(new)) m[new] = t; saveTitles(m) }
            }
        } else saveHistory(d)
    }
}
