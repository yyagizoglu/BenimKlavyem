package com.example.mykeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ClipStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("clips", Context.MODE_PRIVATE)

    // Bozuk/eksik kayıt klavyeyi çökertmesin
    private fun load(key: String): MutableList<String> = try {
        val a = JSONArray(sp.getString(key, "[]"))
        MutableList(a.length()) { a.getString(it) }
    } catch (_: Exception) { mutableListOf() }
    private fun save(key: String, l: List<String>) {
        sp.edit().putString(key, JSONArray(l).toString()).apply()
    }

    // Sabitlenenlere isteğe bağlı başlık: metin -> başlık (eski kayıtlarla uyumlu, ayrı anahtarda tutulur)
    private fun loadTitles(): MutableMap<String, String> = try {
        val o = JSONObject(sp.getString("titles", "{}"))
        val m = LinkedHashMap<String, String>()
        val ks = o.keys()
        while (ks.hasNext()) { val k = ks.next(); m[k] = o.getString(k) }
        m
    } catch (_: Exception) { mutableMapOf() }
    private fun saveTitles(m: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        sp.edit().putString("titles", o.toString()).apply()
    }
    fun titles(): Map<String, String> = loadTitles()
    fun setTitle(t: String, title: String) {
        val m = loadTitles()
        val clean = title.replace('\n', ' ').trim()
        if (clean.isEmpty()) m.remove(t) else m[t] = clean
        saveTitles(m)
    }
    private fun dropTitle(t: String) {
        val m = loadTitles()
        if (m.remove(t) != null) saveTitles(m)
    }

    // --- Geçmiş zaman damgaları (metin -> ms) ve sabit not renkleri (metin -> palet sırası) ---
    private fun loadLongMap(key: String): MutableMap<String, Long> = try {
        val o = JSONObject(sp.getString(key, "{}"))
        val m = LinkedHashMap<String, Long>()
        val ks = o.keys()
        while (ks.hasNext()) { val k = ks.next(); m[k] = o.getLong(k) }
        m
    } catch (_: Exception) { mutableMapOf() }
    private fun saveLongMap(key: String, m: Map<String, Long>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        sp.edit().putString(key, o.toString()).apply()
    }
    fun times(): Map<String, Long> = loadLongMap("htimes")
    private fun setTime(t: String, at: Long) { val m = loadLongMap("htimes"); m[t] = at; saveLongMap("htimes", m) }

    // Her sabit nota otomatik, birbirinden farklı renk: en az kullanılan palet rengi seçilir
    fun colorFor(t: String, palette: Int): Int {
        val m = loadLongMap("colors")
        m[t]?.let { return (it % palette).toInt() }
        val used = IntArray(palette)
        for (p in pinned()) m[p]?.let { used[(it % palette).toInt()]++ }
        var best = 0
        for (i in 1 until palette) if (used[i] < used[best]) best = i
        m[t] = best.toLong(); saveLongMap("colors", m)
        return best
    }
    private fun dropColor(t: String) { val m = loadLongMap("colors"); if (m.remove(t) != null) saveLongMap("colors", m) }
    private fun putColor(t: String, c: Int) { val m = loadLongMap("colors"); m[t] = c.toLong(); saveLongMap("colors", m) }

    // --- Çöp kutuları: sabitlenenler ve geçmiş AYRI ---
    data class Trash(val text: String, val title: String, val color: Int, val at: Long)
    private fun loadTrash(key: String): MutableList<Trash> = try {
        val a = JSONArray(sp.getString(key, "[]"))
        MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Trash(o.getString("t"), o.optString("title"), o.optInt("c"), o.optLong("at"))
        }
    } catch (_: Exception) { mutableListOf() }
    private fun saveTrash(key: String, l: List<Trash>) {
        val a = JSONArray()
        for (x in l.take(50)) a.put(JSONObject().put("t", x.text).put("title", x.title).put("c", x.color).put("at", x.at))
        sp.edit().putString(key, a.toString()).apply()
    }
    fun pinnedTrash() = loadTrash("ptrash")
    fun historyTrash() = loadTrash("htrash")

    fun restoreFromPinnedTrash(i: Int) {
        val l = loadTrash("ptrash"); val x = l.getOrNull(i) ?: return
        l.removeAt(i); saveTrash("ptrash", l)
        val p = pinned(); p.remove(x.text); p.add(x.text); savePinned(p)
        if (x.title.isNotEmpty()) setTitle(x.text, x.title)
        putColor(x.text, x.color)
    }
    fun restoreFromHistoryTrash(i: Int) {
        val l = loadTrash("htrash"); val x = l.getOrNull(i) ?: return
        l.removeAt(i); saveTrash("htrash", l)
        val h = history(); h.remove(x.text)
        val tm = loadLongMap("htimes"); tm[x.text] = x.at; saveLongMap("htimes", tm)
        var idx = h.size
        for (k in h.indices) if ((tm[h[k]] ?: 0L) < x.at) { idx = k; break }   // eski yerine (zamana göre) geri dön
        h.add(idx, x.text)
        while (h.size > 50) h.removeAt(h.size - 1)
        saveHistory(h)
    }
    fun purgeTrash(pinnedTrash: Boolean, i: Int) {
        val k = if (pinnedTrash) "ptrash" else "htrash"
        val l = loadTrash(k); if (i in l.indices) { l.removeAt(i); saveTrash(k, l) }
    }
    fun emptyTrash(pinnedTrash: Boolean) = saveTrash(if (pinnedTrash) "ptrash" else "htrash", emptyList())

    // Tüm geçmiş çöp kutusuna taşınır (geçmişten silinen buradan geri alınır)
    fun clearHistory() {
        val h = history(); if (h.isEmpty()) return
        val tm = loadLongMap("htimes"); val now = System.currentTimeMillis()
        val tr = loadTrash("htrash")
        tr.addAll(0, h.map { Trash(it, "", 0, tm[it] ?: now) })
        saveTrash("htrash", tr)
        saveHistory(emptyList())
    }

    fun history() = load("history")
    fun pinned() = load("pinned")
    fun saveHistory(l: List<String>) = save("history", l)
    fun savePinned(l: List<String>) = save("pinned", l)

    fun addHistory(t: String) {
        val h = history()
        h.remove(t)
        h.add(0, t)
        while (h.size > 50) h.removeAt(h.size - 1)
        saveHistory(h)
        setTime(t, System.currentTimeMillis())
    }
    fun pin(t: String) {
        val h = history(); h.remove(t); saveHistory(h)
        val p = pinned(); p.remove(t); p.add(t); savePinned(p)   // yeni sabit sona eklenir: numara kaldığı yerden devam eder
    }
    // Silinen sabiti eski yerine geri koy
    fun restorePinned(t: String, idx: Int) {
        val h = history(); if (h.remove(t)) saveHistory(h)
        val p = pinned(); p.remove(t); p.add(idx.coerceIn(0, p.size), t); savePinned(p)
    }
    fun unpin(t: String) {
        val p = pinned(); p.remove(t); savePinned(p)
        dropColor(t)
        addHistory(t)
    }
    // Silinen not çöp kutusuna gider (sabitler ve geçmiş ayrı kutularda)
    fun delete(t: String, fromPinned: Boolean) {
        val now = System.currentTimeMillis()
        if (fromPinned) {
            val title = loadTitles()[t] ?: ""
            val col = (loadLongMap("colors")[t] ?: 0L).toInt()
            val tr = loadTrash("ptrash"); tr.add(0, Trash(t, title, col, now)); saveTrash("ptrash", tr)
            val p = pinned(); p.remove(t); savePinned(p)
            dropTitle(t); dropColor(t)
        } else {
            val at = loadLongMap("htimes")[t] ?: now
            val tr = loadTrash("htrash"); tr.add(0, Trash(t, "", 0, at)); saveTrash("htrash", tr)
            val h = history(); h.remove(t); saveHistory(h)
        }
    }
    fun replace(old: String, new: String, fromPinned: Boolean) {
        val l = if (fromPinned) pinned() else history()
        val i = l.indexOf(old)
        if (i < 0) return
        l[i] = new
        val d = l.distinct()
        if (fromPinned) {
            savePinned(d)
            // Metin değişince başlık da yeni metne taşınsın
            if (old != new) {
                val m = loadTitles()
                val t = m.remove(old)
                if (t != null) { if (!m.containsKey(new)) m[new] = t; saveTitles(m) }
                val cm = loadLongMap("colors"); val c = cm.remove(old)
                if (c != null) { cm[new] = c; saveLongMap("colors", cm) }
            }
        } else {
            saveHistory(d)
            if (old != new) { val tm = loadLongMap("htimes"); val t = tm.remove(old); if (t != null) { tm[new] = t; saveLongMap("htimes", tm) } }
        }
    }
}
