package com.example.mykeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock

/** Ataç menüsü için saydam seçici. EXTRA_KIND: 0 fotoğraf, 1 video, 2 belge. */
class PickerActivity : Activity() {
    companion object { const val EXTRA_KIND = "kind" }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return   // döndürme vb. sonrası seçici zaten açık
        try {
            val kind = intent.getIntExtra(EXTRA_KIND, 2)
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                when (kind) {
                    0 -> type = "image/*"
                    1 -> type = "video/*"
                    else -> type = "*/*"   // her tür belge/dosya seçilebilsin (kısıtlama yok)
                }
            }
            startActivityForResult(i, 1)
        } catch (_: Exception) {
            android.widget.Toast.makeText(this, "Dosya seçici açılamadı", android.widget.Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val mime = try { contentResolver.getType(uri) } catch (_: Exception) { null } ?: "application/octet-stream"
            ImeService.pending = Pair(uri, mime)
            ImeService.pendingAt = SystemClock.elapsedRealtime()
        }
        finish()
    }
}
